#!C:\Users\DELL\AppData\Local\Programs\Python\Python37\python.exe
import cgi,cgitb
import sqlite3



conn = sqlite3.connect("users.db")
cur = conn.execute("select username from login where flag = 1")
for row in cur:
    userid = row[0]

selected = cgi.FieldStorage()

cursor = conn.execute("select * from cart where username = '" + userid + "';")

for rows in cursor:
    foodid = rows[1]
    sel = selected.getvalue(str(foodid))
    if (sel=="on"):
            
        quantit = 0
        qu1 = "select quantity,price from cart where username = '" + userid + "' and id = '" + str(foodid) + "';"
        ccc = conn.execute(qu1)
        for f in ccc:
                quantit = f[0]
                pr = f[1]
        if (quantit == 1):
                qu = "delete from cart where username = '" + userid + "' and id = '" + str(foodid) + "';"
                conn.execute(qu)
        else:
                pr = (pr/quantit)
                quantit = quantit - 1
                pr = pr* quantit
                exe = "update cart set quantity = " + str(quantit) + ",price = " + str(pr) + " where username = '" + userid + "' and id = '" + str(foodid) + "';"
                conn.execute(exe)




        

                
        




conn.commit()
print("content-type:text/html\r\n\r\n")
print("<html>")
scriptstr = "<script src= \"../js/cart/deletecart.js\"></script>"
print (scriptstr)
a = "<body onload = \"redirect()\">"
print (a)






print("</body></html>")