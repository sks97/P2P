#!C:\Users\DELL\AppData\Local\Programs\Python\Python37\python.exe

import cgi,cgitb
import sqlite3



conn = sqlite3.connect("users.db")
cur = conn.execute("select username from login where flag = 1")
for row in cur:
    userid = row[0]



selected = cgi.FieldStorage()


cursor = conn.execute("select count(*) from menu where exist = 1;")
for row in cursor:
    size = row[0]
    break

menulist = []
cur = conn.execute("select id from menu where exist = 1;")
for row in cur:
    menulist.append(row[0])


# s = []
# count = 0




for i in menulist[:]:
    foodquan = int(selected.getvalue(str(i)))
    st = "select quantity,price from cart where username = '" + userid + "' and id = '" + str(i) + "';"
    curosr = conn.execute(st)
    quant = -1
    for f in curosr:
        quant = f[0]
        pr = f[1]
    
    if (quant > 0 and foodquan>0):
        
        newprice = (pr/quant)
        quant = quant + foodquan
        newprice = newprice * quant
        exe = "update cart set quantity = " + str(quant) + ",price = " + str(newprice) + " where username = '" + userid + "' and id = '" + str(i) + "';"
        conn.execute(exe)
        

    elif (foodquan>0):
        qu = "select * from menu where id = '" + str(i) + "';"
        cur = conn.execute(qu)
        for rowe in cur:
            

            newprice = int(rowe[3]) * foodquan
            stri = "insert into cart values ('" + str(userid) + "','" + str(rowe[0]) + "','" + str(rowe[1]) + "','" + str(rowe[2]) + "'," + str(newprice)+ ",'" + str(rowe[4]) + "' ," +str(foodquan) + ");"
            conn.execute(stri)
            
            
            
             
           
        
            



conn.commit()
print("content-type:text/html\r\n\r\n")
print("<html>")
scriptstr = "<script src= \"../js/cart/addcart.js\"></script>"
print (scriptstr)
a = "<body onload = \"redirect()\">"
print (a)






print("</body></html>")


