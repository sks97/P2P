#!C:\Users\DELL\AppData\Local\Programs\Python\Python37\python.exe

import cgi,cgitb
import sqlite3

conn = sqlite3.connect("users.db")

#putting values in the database. Can be done in a different python file too


conn.execute("update login set flag = 0 where username = (select username from login);")
cursor = conn.execute("select * from login;")


ab = cgi.FieldStorage()
userinp = ab.getvalue("email")
passinp = ab.getvalue("pass")
conn.execute("insert into login (username,password,flag) values ('"+userinp+"' , '"+passinp+"' , 0);")
conn.commit()
print("content-type:text/html\r\n\r\n")
a = "<html>"
print (a)
b = "<body onload = \"regdirect()\">"
print(b)
print("<script src= \"../js/login/register.js\"></script>")
print("</body></html>")
