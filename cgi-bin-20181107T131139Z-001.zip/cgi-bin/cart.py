#!C:\Users\DELL\AppData\Local\Programs\Python\Python37\python.exe
import sqlite3
conn = sqlite3.connect("users.db")

ide = []
name = []
price = []
typef = []
description = []
url = []
quant = []
useridd = conn.execute("select username from login where flag = 1")

for r in useridd:
    us = r[0]


si = conn.execute("select count(*) from cart where username = '" + us + "';")
for row in si:
    size = row[0]
    break

cursor = conn.execute("select * from cart where username = '" + us + "';")

for rows in cursor:
    ide.append(rows[1])
    name.append(rows[2])
    price.append(rows[4])
    
    description.append(rows[3])
    url.append(rows[5])
    quant.append(str(rows[6]))
cursr = conn.execute("select sum(price) from cart where username = '" + us + "';")
for ro in cursr:
    sum = ro[0];


print("content-type:text/html\r\n\r\n")
a = "<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/cart.css\">"
print("<html><body><form method = \"get\" action = \"../cgi-bin/deletecart.py\">")
print("<script src= \"../js/cart/cart.js\"></script>")
print (a)

inn = "<div id=\"navbar\"><ul><li><a href=\"../home.html\">Home</a></li><li><a>News</a></li><li><a>Contact</a></li><li><a href = \"../cgi-bin/menu.py\">Menu</a></li></ul></div><div>"
print(inn)
ht = "<table border=\"0\" cellpadding=\"10px\" cellspacing=\"10px\" class=\"content\">"
print (ht)
j = 0

print("<tr>")
for i in range(size):
    
    j = j + 1
    
    
    ht1 = "<td>"
    ht2 = "<img src = \"" + url[i] + "\" id = \"" + ide[i] + "\" onmouseover = \"showDescription(this)\" onmouseout = \"hideDescription(this)\"><br>"


    ht3 = "<label>" +  name[i] + "</label>" + "<input type = \"checkbox\" class = \"chosen\" name = \"" + ide[i] + "\"><br>"
    ht7 = "<label>Quantity selected:\t" + quant[i] + "</label><br>"
    ht4 = "<p>"
    ht5 = "</p>"
    ht6 = "<p style = \"visibility:hidden;\" class = \"" + ide[i] + "\">" + description[i] + "</p>"


    ht8 = "</td>"
    print(ht1)
    print(ht2)
    print(ht3)
    print(ht7)
    print(ht4)
    print("Rs")
    print(price[i])
    print(ht5)
    
    print(ht6)
    
    print(ht8)
    if (j%3==0):
        print("</tr><tr>")
    if (i==size-1):
        print("</tr></table><center>")
        but = "<input type = \"submit\" class = \"add\" onclick =\"cartAdd(" 
        print(but)
        print(size)
        bu2 = "\") value = \"Remove from cart\"><br>"
        print(bu2)
        print("<label class = \"add\" value = \"sum\">Total amount is:\t" + str(sum) + "</div></center>")



print("</body></html>")
    
