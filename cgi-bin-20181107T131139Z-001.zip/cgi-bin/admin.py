#!C:\Users\DELL\AppData\Local\Programs\Python\Python37\python.exe
import sqlite3
conn = sqlite3.connect("users.db")

ide = []
name = []
price = []
typef = []
description = []
url = []
exist = []


si = conn.execute("select count(*) from menu;")
for row in si:
    size = row[0]
    break

cursor = conn.execute("select * from menu;")

for rows in cursor:
    ide.append(rows[0])
    name.append(rows[1])
    price.append(rows[3])
    typef.append(rows[5])
    description.append(rows[2])
    url.append(rows[4])
    exist.append(rows[6])



print("content-type:text/html\r\n\r\n")
a = "<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/menu.css\">"
print("<html><body><form method = \"get\" action = \"../cgi-bin/updatemenu.py\">")
print("<script src= \"../js/menu/menu.js\"></script>")
print (a)

inn = "<div id=\"navbar\"><ul><li><a href=\"../index.html\">Back to login</a></li><li><a href = \"../cgi-bin/allcart.py\">View all orders</a></li></ul></div>"
print(inn)
ht = "<table border=\"0\" cellpadding=\"10px\" cellspacing=\"10px\" class=\"content\">"
print (ht)
j = 0
print("<tr>")
for i in range(size):
    j = j + 1
    
    
    ht1 = "<td>"
    ht2 = "<img src = \"" + url[i] + "\" id = \"" + ide[i] + "\" onmouseover = \"showDescription(this)\" onmouseout = \"hideDescription(this)\"><br>"


    if (exist[i]==1):
        ht7 = "<label>" +  name[i] + "</label>" + "<select name = \"" + ide[i] + "\"><option value = \"1\">1</option><option value = \"0\">0</option></select>"
    else:
        ht7 = "<label>" +  name[i] + "</label>" + "<select name = \"" + ide[i] + "\"><option value = \"0\">0</option><option value = \"1\">1</option></select>"

    
    
    ht4 = "<p>"
    ht5 = "</p>"
    ht6 = "<p style = \"visibility:hidden;\" class = \"" + ide[i] + "\">" + description[i] + "</p>"


    ht8 = "</td>"
    print(ht1)
    print(ht2)
    print(ht7)
    print(ht4)
    print("Rs")
    print(price[i])
    print(ht5)
    
    print(ht6)
    
    print(ht8)
    if (j==size):
        print("</tr></table>")
    else:
        if (j%3==0):
            print("</tr><tr>")


but = "<center><input type = \"submit\" onclick =\"cartAdd(" 
print(but)
        
bu2 = "\") value = \"Update menu!!\"></center>"
print(bu2)



print("</body></html>")
    
