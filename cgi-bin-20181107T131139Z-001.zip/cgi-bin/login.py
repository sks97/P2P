#!C:\Users\DELL\AppData\Local\Programs\Python\Python37\python.exe
import cgi,cgitb
import sqlite3

conn = sqlite3.connect("users.db")

#putting values in the database. Can be done in a different python file too


conn.execute("update login set flag = 0 where username = (select username from login);")
cursor = conn.execute("select * from login;")


ab = cgi.FieldStorage()
userinp = ab.getvalue("email")
passinp = ab.getvalue("pass")


log = 0

c=""
for rows in cursor:
    if (userinp ==rows[0] and passinp==rows[1]):
        log = 1

print("content-type:text/html\r\n\r\n")
a = "<html>"
print (a)
if userinp=="admin@gmail.com" and  passinp=="admin":
    c="<body onload = \"admindirect()\">"
    print(c)
else:
    b = "<body onload = \"direct()\">"
    print(b)



if (log==1):
    
   
    flset = "update login set flag = 1 where username = '" + userinp + "'"
    conn.execute(flset)
    conn.commit()
    print('<script>localStorage[0] = "' + userinp + "\"</script>")
    print("<script src= \"../js/login/loginsuccess.js\"></script>")
    
    
    
    #This script redirects to the next html page    (home.html).
    
else:

    
    print("<script src= \"../js/login/loginfail.js\"></script>")
    
    #this script redirects to the login page again with a prompt



print("</body></html>")


