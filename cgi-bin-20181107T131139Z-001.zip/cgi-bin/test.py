#!C:\Users\DELL\AppData\Local\Programs\Python\Python37\python.exe
import cgi,cgitb
import sqlite3



conn = sqlite3.connect("users.db")
cur = conn.execute("select username from login where flag = 1")
for row in cur:
    userid = row[0]



selected = cgi.FieldStorage()

cursor = conn.execute("select count(*) from menu where exist = 1;")
for row in cursor:
    size = row[0]
    break


# s = []
# count = 0




for i in range (1,size + 1):
    foodquan = int(selected.getvalue(str(i)))
    st = "select quantity from cart where username = '" + userid + "' and id = '" + str(i) + "';"
    curosr = conn.execute(st)
    quant = -1
    for f in curosr:
        quant = f[0]
    
    if (quant > -1):
        
        quant = quant + foodquan
        exe = "update cart set quantity = " + str(quant) + " where username = '" + userid + "' and id = '" + str(i) + "';"
        conn.execute(exe)

    else:
        qu = "select * from menu where id = '" + str(i) + "';"
        cur = conn.execute(qu)
        for rowe in cur:
            


            stri = "insert into cart values ('" + str(userid) + "','" + str(rowe[0]) + "','" + str(rowe[1]) + "','" + str(rowe[2]) + "'," + str(rowe[3])+ ",'" + str(rowe[4]) + "' ," +str(foodquan) + ");"
            conn.execute(stri)
            
            
            
             
           
        
            



conn.commit()
print("content-type:text/html\r\n\r\n")
print("<html>")
scriptstr = "<script src= \"../js/cart/addcart.js\"></script>"
print (scriptstr)
a = "<body onload = \"redirect()\">"
print (a)






print("</body></html>")


