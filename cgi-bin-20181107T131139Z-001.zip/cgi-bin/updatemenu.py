#!C:\Users\DELL\AppData\Local\Programs\Python\Python37\python.exe

import cgi,cgitb
import sqlite3



conn = sqlite3.connect("users.db")




selected = cgi.FieldStorage()

cursor = conn.execute("select count(*) from menu;")
for row in cursor:
    size = row[0]
    break


# s = []
# count = 0




for i in range (1,size+1):
    exist = int(selected.getvalue(str(i)))
    if (exist==1):
        st = "update menu set exist = 1 where id = '" + str(i) + "';"
        conn.execute(st) 
    elif (exist==0):
        st = "update menu set exist = 0 where id = '" + str(i) + "';"
        conn.execute(st) 
    
            
conn.execute(st)            
            
             
           
        
            



conn.commit()
print("content-type:text/html\r\n\r\n")


scriptstr = "<script src= \"../js/admin/admin.js\"></script>"
print (scriptstr)
a = "<body onload = \"redirect()\">"
print (a)






print("</body></html>")


