#!C:\Users\DELL\AppData\Local\Programs\Python\Python37\python.exe
import sqlite3

conn = sqlite3.connect("users.db")

conn.execute("drop table if exists login")
conn.execute("create table login (username varchar(40) , password varchar(40) , flag integer , primary key(username));")
conn.execute("insert into login (username,password,flag) values ('user1@gmail.com' , 'p1' , 1);")
conn.execute("insert into login (username,password,flag) values ('user2@gmail.com' , 'password2' , 0);")



conn.execute("drop table if exists menu")
conn.execute("create table menu (id varchar(20) , name varchar(40)  , description varchar(300) , price integer ,image varchar(40) , type varchar(10) , exist integer , primary key(id));")
conn.execute("insert into menu (id,name,description , price , image , type , exist) values ('1' , 'Peppy Paneer' , 'Paneer hai bohot saara pizza me' , 400 , '../images/img-01.jpg' , 'pizza', 1);")
conn.execute("insert into menu (id,name,description , price , image , type , exist) values ('2' , 'Peppy Paneer' , 'Paneer hai bohot saarddddda pizza me' , 400 , '../images/img-01.jpg' , 'pizza', 1);")
conn.execute("insert into menu (id,name,description , price , image , type , exist) values ('3' , 'Peppy Paneer' , 'Paneerdd hai bohot saara pizza me' , 400 , '../images/img-01.jpg' , 'pizza', 1);")
conn.execute("insert into menu (id,name,description , price , image , type , exist) values ('4' , 'Pepeeepy Paneer' , 'Paneer haisdfsdf bohot sdfsdfsaasdfsdfra pizza me' , 400 , '../images/img-01.jpg' , 'pizza', 1);")
conn.execute("insert into menu (id,name,description , price , image , type , exist) values ('8' , 'Pepeeepy Paneer' , 'Paneer haisdfsdf bohot sdfsdfsaasdfsdfra pizza me Paneer haisdfsdf ' , 400 , '../images/img-01.jpg' , 'pizza', 1);")
conn.execute("insert into menu (id,name,description , price , image , type , exist) values ('5' , 'Pepeeepy Paneer' , 'Paneer haisdfsdf bohot sdfsdfsaasdfsdfra pizza me' , 400 , '../images/img-01.jpg' , 'pizza', 1);")
conn.execute("insert into menu (id,name,description , price , image , type , exist) values ('6' , 'Pepeeepy Paneer' , 'Paneer haisdfsdf bohot sdfsdfsaasdfsdfra pizza me' , 400 , '../images/img-01.jpg' , 'pizza', 1);")
conn.execute("insert into menu (id,name,description , price , image , type , exist) values ('7' , 'Pepeeepy Paneer' , 'Paneer haisdfsdf bohot sdfsdfsaasdfsdfra pizza me' , 400 , '../images/img-01.jpg' , 'pizza', 1);")
conn.execute("insert into menu (id,name,description , price , image , type , exist) values ('10' , 'Not Pepeeepy Paneer' , 'Paneer haisdfsdf bohot sdfsdfsaasdfsdfra pizza me' , 400 , '../images/img-01.jpg' , 'pizza', 0);")
conn.execute("insert into menu (id,name,description , price , image , type , exist) values ('9' , ' Not Pepeeepy Paneer2' , 'Paneer haisdfsdf bohot sdfsdfsaasdfsdfra pizza me' , 400 , '../images/img-01.jpg' , 'pizza', 0);")
conn.execute("insert into menu (id,name,description , price , image , type , exist) values ('11' , ' Not Pepeeepy Paneer3' , 'Paneer haisdfsdf bohot sdfsdfsaasdfsdfra pizza me' , 400 , '../images/img-01.jpg' , 'pizza', 0);")
conn.execute("drop table if exists cart")
conn.execute("create table cart (username varchar(40) , id varchar(20) , name varchar(40)  , description varchar(300) , price integer ,image varchar(40), quantity integer);")
conn.execute("delete from cart;")




conn.commit()