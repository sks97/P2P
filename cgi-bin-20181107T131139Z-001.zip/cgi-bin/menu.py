#!C:\Users\DELL\AppData\Local\Programs\Python\Python37\python.exe
import sqlite3
conn = sqlite3.connect("users.db")

ide = []
name = []
price = []
typef = []
description = []
url = []


si = conn.execute("select count(*) from menu where exist = 1;")
for row in si:
    size = row[0]
    break

cursor = conn.execute("select * from menu where exist = 1;")

for rows in cursor:
    ide.append(rows[0])
    name.append(rows[1])
    price.append(rows[3])
    typef.append(rows[5])
    description.append(rows[2])
    url.append(rows[4])



print("content-type:text/html\r\n\r\n")
a = "<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/menu.css\">"
print("<html><body><form method = \"get\" action = \"../cgi-bin/addtocart.py\">")
print("<script src= \"../js/menu/menu.js\"></script>")
print (a)

inn = "<div id=\"navbar\"><ul><li><a href=\"../home.html\">Home</a></li><li><a>News</a></li><li><a>Contact</a></li><li><a href = \"../cgi-bin/cart.py\">View cart</a></li></ul></div>"
print(inn)
ht = "<table border=\"0\" cellpadding=\"10px\" cellspacing=\"10px\" class=\"content\">"
print (ht)
j = 0
print("<tr>")
for i in range(size):
    j = j + 1
    
    
    ht1 = "<td>"
    ht2 = "<img src = \"" + url[i] + "\" id = \"" + ide[i] + "\" onmouseover = \"showDescription(this)\" onmouseout = \"hideDescription(this)\"><br>"


    #ht3 = "<label>" +  name[i] + "</label>" + "<input type = \"checkbox\" class = \"chosen\" name = \"" + ide[i] + "\"><br>"
    ht7 = "<label>" +  name[i] + "</label>" + "<select name = \"" + ide[i] + "\"><option value = \"0\">0</option><option value = \"1\">1</option><option value = \"2\">2</option><option value = \"3\">3</option></select>"
    ht4 = "<p>"
    ht5 = "</p>"
    ht6 = "<p style = \"visibility:hidden;\" class = \"" + ide[i] + "\">" + description[i] + "</p>"


    ht8 = "</td>"
    print(ht1)
    print(ht2)
    print(ht7)
    print(ht4)
    print("Rs")
    print(price[i])
    print(ht5)
    
    print(ht6)
    
    print(ht8)
    if (j%3==0):
        print("</tr><tr>")
    if (i==size-1):
        print("</tr></table>")
        but = "<center><input type = \"submit\" onclick =\"cartAdd(" 
        print(but)
        print(size)
        bu2 = "\") value = \"Add to cart!!!\"></center>"
        print(bu2)



print("</body></html>")
    
