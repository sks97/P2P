#!C:\Users\DELL\AppData\Local\Programs\Python\Python37\python.exe
import sqlite3
conn = sqlite3.connect("users.db")


user = []
name = []
ids = []
quantity = []
price = []


cursor = conn.execute("select * from cart;")
for row in cursor:
    user.append(row[0])
    name.append(row[2])
    ids.append(row[1])
    quantity.append(str(row[6]))
    price.append(str(row[4]))


size = len(user)

print("content-type:text/html\r\n\r\n")
print("<html><body><table border = \"1\"")
print("<tr><th>Userid</th><th>food name</th><th>food id</th><th>quantity</th><th>price</th></tr>")
for i in range (size):
    print("<tr>")
    print("<td>" + user[i] + "</td>")
    print("<td>" + name[i] + "</td>")
    print("<td>" + ids[i] + "</td>")
    print("<td>" + quantity[i] + "</td>")
    print("<td>" + price[i] + "</td>")
    print("</tr>")

print("</table></body></html>")

