#!C:\Users\satya\AppData\Local\Programs\Python\Python36\python.exe
import cgi,cgitb
import sqlite3

conn = sqlite3.connect("users.db")
selected = cgi.FieldStorage()

cursor = conn.execute("select count(*) from menu;")
for row in cursor:
    size = row[0]
    break
s = []
count = 0
for i in range (size):
    foodid = selected.getvalue(i)





print("content-type:text/html\r\n\r\n")
a = "<html><body>"
print (a)
print("<h1>" + foodid +"</h1>")
print("<h1>" + val +"</h1>")
print("</body></html>")

