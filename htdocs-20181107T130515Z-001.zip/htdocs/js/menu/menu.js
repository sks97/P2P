function showDescription(ele){
    myid = ele.id;
    ab = document.getElementsByClassName(myid);
    ab[0].style.visibility = "visible";
    


}
function hideDescription(ele){
    myid = ele.id;
    ab = document.getElementsByClassName(myid);
    ab[0].style.visibility = "hidden";


}