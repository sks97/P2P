function redirect(){
    //window.alert("Items added to cart!\nYou will be redirected back to the menu")
    window.location.href = "/cgi-bin/cart.py";
}