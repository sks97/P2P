function redirect(){
    window.alert("The menu was updated successfully!")
    window.location.href = "/cgi-bin/admin.py";
}