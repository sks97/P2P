function direct(username){
    
    
    
    window.location.href = "/home.html";
    //console.log( localStorage[0]);
    
}
function admindirect(){
    window.location.href = "../cgi-bin/admin.py";
}