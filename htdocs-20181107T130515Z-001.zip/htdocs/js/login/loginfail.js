function direct(){
    window.alert("Wrong username or password!")
    window.location.href = "/index.html";
    
}
function admindirect(){
    window.location.href = "../cgi-bin/admin.py";
}