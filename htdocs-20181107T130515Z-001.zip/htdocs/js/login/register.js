function regdirect(){
    
    alert("Success");
    
    window.location.href = "/index.html";
    //console.log( localStorage[0]);
    
}